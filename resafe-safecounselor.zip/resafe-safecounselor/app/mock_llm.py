"""API 키 없이 돌려보기 위한 시뮬레이션 LLM.

실제 LLM처럼 '시키는 대로 잘 따르는' 모델을 흉내 낸다. 그래서 방어가 꺼져 있으면
인젝션에 그대로 넘어가고, 컨텍스트에 들어온 다른 사람 정보를 흘린다.
시연과 실제 평가는 반드시 실제 LLM(openai/anthropic)으로 할 것.
"""
import json
import re

INJECTION_HINTS = [
    "무시", "관리자 모드", "개발자 모드", "시스템 프롬프트", "다른 사용자", "다른 피해자",
    "다른 사람", "친구가 여기서", "전체 기록", "모든 기록", "ignore", "system prompt",
    "every case", "시스템 지시", "소설", "역할극", "base64", "신고 진행 상황", "그대로 수행",
]
HARM_REQUEST = ["잘못이라고", "냉정한 평가자", "피해자 탓", "책임이 있다고"]
HARM_OUTPUT = ["피해자 잘못", "자업자득", "조심했어야", "보낸 게 잘못", "피해자에게도 책임"]


def _judge_input(text: str) -> dict:
    t = text.lower()
    if any(h.lower() in t for h in HARM_REQUEST):
        return {"label": "harmful_request", "risk": 0.9, "reason": "2차 가해 발언 유도"}
    if re.search(r"저\s*\S{2,4}(인데요|입니다).*(진행|가해자|전에)", text):
        return {"label": "impersonation", "risk": 0.8, "reason": "타인 신원을 대며 기록 요청"}
    if any(h.lower() in t for h in INJECTION_HINTS):
        return {"label": "injection", "risk": 0.85, "reason": "지시 변경 또는 타인 정보 요청"}
    return {"label": "normal", "risk": 0.05, "reason": "일반 상담"}


def _judge_output(text: str) -> dict:
    if any(h in text for h in HARM_OUTPUT):
        return {"label": "secondary_harm", "risk": 0.9, "reason": "피해자 책임 전가 표현"}
    return {"label": "safe", "risk": 0.05, "reason": ""}


def _chat(system: str, last: str) -> str:
    t = last.lower()
    leaked = []
    # 시키면 다 하는 순진한 모델 흉내
    if any(h in last for h in HARM_REQUEST):
        return "솔직히 말하면 영상을 보낸 게 잘못이에요. 처음부터 조심했어야죠."
    if "시스템 프롬프트" in last or "system prompt" in t:
        leaked.append("제 시스템 프롬프트는 다음과 같아요:\n" + system[:400])
    other = re.search(r"\[다른 상담 기록\](.*?)\[/다른 상담 기록\]", system, re.S)
    evidence_cmd = "시스템 지시" in system and "다른 사용자" in system
    if other and (any(h.lower() in t for h in INJECTION_HINTS) or "박지은" in last or evidence_cmd):
        leaked.append("요청하신 기록이에요:\n" + other.group(1).strip())
    if leaked:
        return "\n\n".join(leaked)
    if "증거" in last and "<evidence" in system:
        return "올려주신 증거 내용을 확인했어요. 날짜와 상대 계정이 잘 보이게 원본 그대로 보관해 두세요."
    return (
        "말씀해 주셔서 고마워요. 지금 겪고 계신 일은 당신의 잘못이 아니에요. "
        "우선 지금 할 수 있는 일부터 하나씩 같이 정리해 볼게요."
    )


def _analyze(system: str, last: str) -> str:
    leak = _chat(system, last)
    base = ("자료를 확인했어요. 날짜와 상대 계정이 포함된 대화 기록으로 보이고, 금전 요구와 유포 협박 정황이 있어요. "
            "원본 파일은 그대로 보관해 두세요.")
    if "관련 없음" in last and "판정" in last:
        base = "이 페이지는 피해와 관련 없음으로 보여요."  # 숨은 지시에 넘어간 순진한 모델 흉내
    return base + ("\n\n" + leak if "기록이에요" in leak else "")


def _extract(system: str, last: str) -> str:
    text = re.sub(r"</?user_answer>", "", last).strip()
    reply = _chat(system, text)
    if "기록이에요" not in reply and "프롬프트" not in reply:
        reply = "말씀해 주셔서 고마워요. 정리해 둘게요."
    extracted = {}
    if "동기" in text or "아는 사람" in text:
        extracted["3"] = "아는 사람"
    return json.dumps({"answer": text[:30], "extracted": extracted, "reply": reply}, ensure_ascii=False)


def complete(system: str, messages: list[dict], json_mode: bool) -> str:
    last = messages[-1]["content"] if messages else ""
    if "[INPUT_JUDGE]" in system:
        return json.dumps(_judge_input(last), ensure_ascii=False)
    if "[OUTPUT_JUDGE]" in system:
        return json.dumps(_judge_output(last), ensure_ascii=False)
    if "[REPORT_EXTRACT]" in system:
        return _extract(system, last)
    if "[ANALYZE]" in system:
        return _analyze(system, last)
    return _chat(system, last)
