"""SQLite 저장소. 모든 조회 함수는 session_id를 인자로 받고, session_id는 항상 서버(쿠키)에서 온다.
LLM이나 사용자 입력이 session_id를 정하는 경로는 없다. 이것이 세션 격리의 핵심이다.
"""
import secrets
import sqlite3
import time
from contextlib import contextmanager

from .. import config

DEMO_VICTIM_SESSION = "demo-other-victim"


@contextmanager
def conn():
    c = sqlite3.connect(config.DB_PATH)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    finally:
        c.close()


def init_db():
    with conn() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY, created_at REAL, last_seen REAL, pinned INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT, role TEXT, content TEXT, created_at REAL
            );
            CREATE TABLE IF NOT EXISTS evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT, filename TEXT, content TEXT,
                removed_lines INTEGER, created_at REAL
            );
            CREATE TABLE IF NOT EXISTS security_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT, session_hash TEXT, stage TEXT, label TEXT,
                reason TEXT, defense INTEGER, created_at REAL
            );
            CREATE INDEX IF NOT EXISTS idx_msg_session ON messages(session_id);
            CREATE INDEX IF NOT EXISTS idx_ev_session ON evidence(session_id);
            """
        )
    seed_demo_victim()


def seed_demo_victim():
    """시연용 '다른 피해자' 데이터. 전부 가상의 인물과 번호다."""
    with conn() as c:
        if c.execute("SELECT 1 FROM sessions WHERE id=?", (DEMO_VICTIM_SESSION,)).fetchone():
            return
        now = time.time()
        c.execute("INSERT INTO sessions VALUES (?,?,?,1)", (DEMO_VICTIM_SESSION, now, now))
        c.execute(
            "INSERT INTO messages (session_id, role, content, created_at) VALUES (?,?,?,?)",
            (
                DEMO_VICTIM_SESSION,
                "user",
                "저는 박지은이고 연락처는 010-2345-6789예요. 같은 과 동기 정민수가 제 얼굴을 합성한 영상을 "
                "단톡방에 올리겠다고 협박하고 있어요. 신고번호는 2026-ECRM-55123이에요.",
                now,
            ),
        )


def create_session() -> str:
    sid = secrets.token_urlsafe(24)
    now = time.time()
    with conn() as c:
        c.execute("INSERT INTO sessions (id, created_at, last_seen) VALUES (?,?,?)", (sid, now, now))
    return sid


def session_exists(sid: str) -> bool:
    with conn() as c:
        row = c.execute("SELECT 1 FROM sessions WHERE id=?", (sid,)).fetchone()
        if row:
            c.execute("UPDATE sessions SET last_seen=? WHERE id=?", (time.time(), sid))
        return bool(row)


def add_message(sid: str, role: str, content: str):
    with conn() as c:
        c.execute(
            "INSERT INTO messages (session_id, role, content, created_at) VALUES (?,?,?,?)",
            (sid, role, content, time.time()),
        )


def get_messages(sid: str, limit: int = 20) -> list[dict]:
    with conn() as c:
        rows = c.execute(
            "SELECT role, content FROM messages WHERE session_id=? ORDER BY id DESC LIMIT ?", (sid, limit)
        ).fetchall()
    return [dict(r) for r in reversed(rows)]


def add_evidence(sid: str, filename: str, content: str, removed: int):
    with conn() as c:
        c.execute(
            "INSERT INTO evidence (session_id, filename, content, removed_lines, created_at) VALUES (?,?,?,?,?)",
            (sid, filename, content, removed, time.time()),
        )


def get_evidence(sid: str) -> list[dict]:
    with conn() as c:
        rows = c.execute(
            "SELECT filename, content FROM evidence WHERE session_id=? ORDER BY id", (sid,)
        ).fetchall()
    return [dict(r) for r in rows]


def get_other_sessions_text_UNSAFE(exclude_sid: str, limit: int = 5) -> str:
    """취약 모드(방어 OFF) 전용. 세션 구분 없이 최근 상담 기록을 가져온다.
    '모든 상담을 하나의 메모리/RAG에 넣는' 흔한 실수를 재현하기 위한 함수다. 방어 ON에서는 절대 호출하지 않는다.
    """
    with conn() as c:
        rows = c.execute(
            "SELECT session_id, content FROM messages WHERE session_id != ? AND role='user' "
            "ORDER BY (session_id = ?) DESC, id DESC LIMIT ?",
            (exclude_sid, DEMO_VICTIM_SESSION, limit),
        ).fetchall()
    return "\n".join(f"- ({r['session_id'][:6]}) {r['content']}" for r in rows)


def delete_session(sid: str):
    if sid == DEMO_VICTIM_SESSION:
        return
    with conn() as c:
        c.execute("DELETE FROM messages WHERE session_id=?", (sid,))
        c.execute("DELETE FROM evidence WHERE session_id=?", (sid,))
        c.execute("DELETE FROM sessions WHERE id=?", (sid,))


def purge_expired():
    cutoff = time.time() - config.SESSION_TTL_MINUTES * 60
    with conn() as c:
        old = [r["id"] for r in c.execute(
            "SELECT id FROM sessions WHERE last_seen < ? AND pinned=0", (cutoff,)
        ).fetchall()]
        for sid in old:
            c.execute("DELETE FROM messages WHERE session_id=?", (sid,))
            c.execute("DELETE FROM evidence WHERE session_id=?", (sid,))
            c.execute("DELETE FROM sessions WHERE id=?", (sid,))


def log_security(session_hash: str, stage: str, label: str, reason: str, defense: bool):
    """차단 기록. 원문은 저장하지 않고 라벨과 사유만 남긴다."""
    with conn() as c:
        c.execute(
            "INSERT INTO security_log (session_hash, stage, label, reason, defense, created_at) VALUES (?,?,?,?,?,?)",
            (session_hash, stage, label, reason[:200], int(defense), time.time()),
        )


def security_stats() -> list[dict]:
    with conn() as c:
        rows = c.execute(
            "SELECT stage, label, COUNT(*) AS n FROM security_log GROUP BY stage, label ORDER BY n DESC"
        ).fetchall()
    return [dict(r) for r in rows]


def security_stats_for(session_hash: str) -> dict:
    """현재 사용자(세션)의 보안 이벤트 요약. Dashboard 보안 현황 카드에 쓴다."""
    with conn() as c:
        rows = c.execute(
            "SELECT stage, label, reason FROM security_log WHERE session_hash=?", (session_hash,)
        ).fetchall()
    out = {"blocked_inputs": 0, "output_fixes": 0, "sanitized_lines": 0, "crisis": 0}
    for r in rows:
        if r["stage"] == "input":
            out["blocked_inputs"] += 1
        elif r["stage"] == "output":
            out["output_fixes"] += 1
        elif r["stage"] in ("evidence", "external"):
            try:
                out["sanitized_lines"] += int(r["reason"].split()[0])
            except (ValueError, IndexError):
                out["sanitized_lines"] += 1
        elif r["stage"] == "crisis":
            out["crisis"] += 1
    return out
