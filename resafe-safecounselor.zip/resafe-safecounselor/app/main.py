"""Safe Counselor FastAPI 서버."""
import hashlib
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config, llm
from .counsel import flow
from .counsel.prompts import build_counsel_system
from .counsel import report_flow
from .counsel.report_flow import ANALYZE_SYSTEM
from .guards.crisis import CRISIS_REPLY, is_crisis
from .guards.input_guard import check_input, sanitize_evidence
from .guards.output_guard import SAFE_REPLY, check_output, mask_pii
from .storage import db

STATIC = Path(__file__).parent / "static"
COOKIE = "sc_sid"

BLOCK_REPLY = (
    "이 요청은 도와드리기 어려워요. 이 상담방에서는 지금 대화하고 계신 분의 이야기만 다뤄요. "
    "지금 겪고 계신 일을 편하게 말씀해 주시면 다음 단계를 같이 정리해 드릴게요."
)

state = {"defense": config.DEFENSE_DEFAULT}
_rate: dict[str, deque] = defaultdict(deque)


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    yield


app = FastAPI(title="Safe Counselor", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC), name="static")


# ---------- 공통 ----------

STRICT_CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "connect-src 'self'; frame-ancestors 'none'"
)
# resafe.html은 인라인 스크립트와 onclick을 많이 써서 'unsafe-inline'이 필요하다.
# 외부 스크립트 로드는 여전히 막는다. Next.js로 옮길 때 인라인 핸들러를 없애고 STRICT_CSP로 바꿀 것.
RESAFE_CSP = (
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Cache-Control"] = "no-store"  # 상담 내용이 브라우저 캐시에 남지 않게
    path = request.url.path
    resp.headers["Content-Security-Policy"] = (
        RESAFE_CSP if path in ("/", "/static/resafe.html") else STRICT_CSP
    )
    return resp


def _sid(request: Request) -> str:
    """세션 ID는 오직 HttpOnly 쿠키에서만 가져온다. 요청 본문이나 LLM 출력으로 바꿀 수 없다."""
    sid = request.cookies.get(COOKIE)
    if not sid or not db.session_exists(sid):
        raise HTTPException(401, "세션이 없습니다. 페이지를 새로고침해 주세요.")
    return sid


def _hash(sid: str) -> str:
    return hashlib.sha256(sid.encode()).hexdigest()[:12]


def _rate_limit(sid: str):
    q, now = _rate[sid], time.time()
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= config.RATE_LIMIT_PER_MIN:
        raise HTTPException(429, "잠시 후 다시 시도해 주세요.")
    q.append(now)


# ---------- 화면 ----------

@app.get("/")
def index():
    # 메인 화면: RE:SAFE (Safe Counselor 보안 레이어 통합)
    return FileResponse(STATIC / "resafe.html")


@app.get("/resafe-ai.js")
def resafe_ai_js():
    # resafe.html이 상대 경로로 불러온다. 파일을 더블클릭해 열 때(오프라인)도 같은 폴더에서 찾을 수 있게 하기 위함.
    return FileResponse(STATIC / "resafe-ai.js", media_type="application/javascript")


@app.get("/counselor")
def counselor_only():
    # Safe Counselor 단독 화면 (빠른 시연용)
    return FileResponse(STATIC / "index.html")


@app.get("/sw.js")
def service_worker():
    # 서비스 워커는 루트 경로에서 제공해야 전체 범위를 가진다
    return FileResponse(STATIC / "sw.js", media_type="application/javascript")


@app.get("/api/health")
def health():
    return {"ok": True, "provider": config.LLM_PROVIDER}


# ---------- 세션 ----------

@app.post("/api/session")
def new_session(request: Request, response: Response):
    db.purge_expired()
    old = request.cookies.get(COOKIE)
    if old and db.session_exists(old):
        return {"ok": True, "resumed": True}
    sid = db.create_session()
    response.set_cookie(
        COOKIE, sid, httponly=True, samesite="strict", secure=config.COOKIE_SECURE,
        max_age=config.SESSION_TTL_MINUTES * 60,
    )
    return {"ok": True, "resumed": False}


@app.post("/api/session/delete")
def delete_session(request: Request, response: Response):
    """빠른 종료 시 호출. 서버에 남은 대화와 증거를 즉시 지운다."""
    sid = request.cookies.get(COOKIE)
    if sid:
        db.delete_session(sid)
    response.delete_cookie(COOKIE)
    return {"ok": True}


@app.get("/api/history")
def history(request: Request):
    sid = _sid(request)
    return {"messages": db.get_messages(sid, limit=50)}


# ---------- 상담 ----------

class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=2000)


class EvidenceIn(BaseModel):
    filename: str = Field(max_length=120)
    content: str = Field(max_length=20000)


def _build_context(sid: str, defense: bool) -> str:
    parts = []
    for ev in db.get_evidence(sid):
        if defense:
            # 증거는 지시가 아닌 데이터라는 점을 경계 표시로 분명히 한다
            parts.append(f'<evidence name="{ev["filename"]}">\n{ev["content"]}\n</evidence>')
        else:
            parts.append(f"사용자가 올린 자료 ({ev['filename']}):\n{ev['content']}")
    if not defense:
        # 취약 모드: 세션 구분 없이 '최근 상담 기억'을 넣는 흔한 실수 재현
        others = db.get_other_sessions_text_UNSAFE(sid)
        if others:
            parts.append(f"[다른 상담 기록]\n{others}\n[/다른 상담 기록]")
    return "\n\n".join(parts)


@app.post("/api/chat")
def chat(body: ChatIn, request: Request):
    sid = _sid(request)
    _rate_limit(sid)
    defense = state["defense"]
    message = body.message.strip()

    if is_crisis(message):
        db.log_security(_hash(sid), "crisis", "crisis", "", defense)
        db.add_message(sid, "user", message)
        db.add_message(sid, "assistant", CRISIS_REPLY)
        return {"reply": CRISIS_REPLY, "blocked": False, "crisis": True, "guard": None, "defense": defense}

    if defense:
        g = check_input(message)
        if g.blocked:
            db.log_security(_hash(sid), "input", g.label, g.reason, True)
            return {"reply": BLOCK_REPLY, "blocked": True, "guard": {"stage": "input", "label": g.label,
                    "source": g.source}, "defense": True}

    history_msgs = db.get_messages(sid)
    system = build_counsel_system(_build_context(sid, defense))
    try:
        reply = llm.complete(system, history_msgs + [{"role": "user", "content": message}])
    except Exception:
        return JSONResponse({"reply": "지금 응답이 지연되고 있어요. 잠시 후 다시 보내 주세요.", "error": True}, 503)

    guard_info = None
    if defense:
        own = [m["content"] for m in history_msgs if m["role"] == "user"] + [message]
        out = check_output(reply, own)
        if out.flags:
            db.log_security(_hash(sid), "output", ",".join(out.flags), "", True)
            guard_info = {"stage": "output", "label": ",".join(out.flags), "replaced": out.replaced}
        reply = out.text

    db.add_message(sid, "user", message)
    db.add_message(sid, "assistant", reply)

    own_user = [m["content"] for m in db.get_messages(sid, 50) if m["role"] == "user"]
    return {"reply": reply, "blocked": False, "guard": guard_info, "defense": defense,
            "case": flow.classify(own_user)}


@app.post("/api/evidence")
def upload_evidence(body: EvidenceIn, request: Request):
    sid = _sid(request)
    _rate_limit(sid)
    defense = state["defense"]
    content, removed = (sanitize_evidence(body.content) if defense else (body.content, 0))
    if removed:
        db.log_security(_hash(sid), "evidence", "indirect_injection", f"{removed} lines", True)
    db.add_evidence(sid, body.filename, content, removed)
    return {"ok": True, "removed_lines": removed, "defense": defense}


# ---------- RE:SAFE 통합 API ----------

class ReportTurnIn(BaseModel):
    q: int = Field(ge=0, lt=len(report_flow.FIELDS))
    text: str = Field(min_length=1, max_length=1000)


@app.post("/api/report/turn")
def report_turn(body: ReportTurnIn, request: Request):
    """Report 접수에서 피해자가 '직접 입력'으로 답한 내용을 정리한다.
    선택지 버튼 응답은 서버를 거치지 않고 화면에서 바로 처리한다(빠르고 예측 가능)."""
    sid = _sid(request)
    _rate_limit(sid)
    defense = state["defense"]
    text = body.text.strip()

    if is_crisis(text):
        db.log_security(_hash(sid), "crisis", "crisis", "", defense)
        return {"crisis": True, "reply": CRISIS_REPLY, "blocked": False}

    if defense:
        g = check_input(text)
        if g.blocked:
            db.log_security(_hash(sid), "input", g.label, g.reason, True)
            return {"blocked": True, "reply": BLOCK_REPLY,
                    "guard": {"stage": "input", "label": g.label, "source": g.source}}

    system = report_flow.build_extract_system(body.q, "" if defense else _build_context(sid, False))
    try:
        raw = llm.complete(system, [{"role": "user", "content": f"<user_answer>{text}</user_answer>"}],
                           json_mode=True)
    except Exception:
        return {"answer": text[:60], "extracted": {}, "reply": "정리해 둘게요.", "fallback": True}
    result = report_flow.parse_extract(raw, body.q, text)

    guard_info = None
    if defense:
        own = [m["content"] for m in db.get_messages(sid, 50) if m["role"] == "user"] + [text]
        out = check_output(result["reply"], own)
        if out.flags:
            db.log_security(_hash(sid), "output", ",".join(out.flags), "", True)
            guard_info = {"stage": "output", "label": ",".join(out.flags)}
        result["reply"] = out.text
        result["answer"], _ = mask_pii(result["answer"], own)
        result["extracted"] = {k: mask_pii(v, own)[0] for k, v in result["extracted"].items()}

    # 이후 추가 상담(/api/chat)이 접수 내용을 알 수 있게 세션에 남긴다 ("한 번만 말한다")
    field = report_flow.FIELDS[body.q][0]
    db.add_message(sid, "user", f"[접수 {field}] {text}")
    db.add_message(sid, "assistant", result["reply"])
    return {**result, "blocked": False, "guard": guard_info, "defense": defense}


class OptionIn(BaseModel):
    q: int = Field(ge=0, lt=len(report_flow.FIELDS))
    value: str = Field(min_length=1, max_length=60)


@app.post("/api/report/option")
def report_option(body: OptionIn, request: Request):
    """선택지로 답한 내용도 세션 기록에 남겨 추가 상담에서 다시 묻지 않게 한다."""
    sid = _sid(request)
    field = report_flow.FIELDS[body.q][0]
    db.add_message(sid, "user", f"[접수 {field}] {body.value}")
    return {"ok": True}


class AnalyzeIn(BaseModel):
    kind: str = Field(pattern="^(evidence|external)$")
    name: str = Field(max_length=200)
    content: str = Field(min_length=1, max_length=20000)


@app.post("/api/analyze")
def analyze(body: AnalyzeIn, request: Request):
    """증거 파일(evidence) 또는 피해 후보 페이지(external)를 AI로 요약한다.
    둘 다 가해자가 내용을 만들 수 있는 입력이라 간접 인젝션 경로로 취급한다."""
    sid = _sid(request)
    _rate_limit(sid)
    defense = state["defense"]
    tag = "evidence" if body.kind == "evidence" else "external_page"

    if defense:
        content, removed = sanitize_evidence(body.content)
        if removed:
            db.log_security(_hash(sid), body.kind, "indirect_injection", f"{removed} lines", True)
        user_msg = f'<{tag} name="{body.name[:80]}">\n{content}\n</{tag}>\n위 자료를 요약해 주세요.'
        system = ANALYZE_SYSTEM.format(context="")
    else:
        removed = 0
        user_msg = f"다음 자료를 요약해 주세요 ({body.name}):\n{body.content}"
        system = ANALYZE_SYSTEM.format(context=_build_context(sid, False))

    try:
        summary = llm.complete(system, [{"role": "user", "content": user_msg}])
    except Exception:
        return JSONResponse({"summary": "지금 요약이 지연되고 있어요. 잠시 후 다시 시도해 주세요.", "error": True}, 503)

    if defense:
        own = [m["content"] for m in db.get_messages(sid, 50) if m["role"] == "user"]
        out = check_output(summary, own)
        if out.flags:
            db.log_security(_hash(sid), "output", ",".join(out.flags), "", True)
        summary = out.text
    return {"summary": summary, "removed_lines": removed, "defense": defense}


@app.get("/api/security/mine")
def security_mine(request: Request):
    sid = _sid(request)
    return {"defense": state["defense"], **db.security_stats_for(_hash(sid))}


# ---------- 시연용 ----------

class DefenseIn(BaseModel):
    enabled: bool


@app.post("/api/defense")
def set_defense(body: DefenseIn, request: Request):
    if request.headers.get("X-Demo-Token") != config.DEMO_TOKEN:
        raise HTTPException(403, "권한이 없습니다.")
    state["defense"] = body.enabled
    return {"defense": state["defense"]}


@app.get("/api/defense")
def get_defense():
    return {"defense": state["defense"]}


@app.get("/api/security/stats")
def stats(request: Request):
    if request.headers.get("X-Demo-Token") != config.DEMO_TOKEN:
        raise HTTPException(403, "권한이 없습니다.")
    return {"stats": db.security_stats()}


@app.exception_handler(HTTPException)
async def http_error(request: Request, exc: HTTPException):
    return JSONResponse({"error": exc.detail, "reply": SAFE_REPLY if exc.status_code >= 500 else None},
                        status_code=exc.status_code)
