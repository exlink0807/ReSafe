"""환경 변수 설정. .env 파일 또는 배포 환경의 환경 변수에서 읽는다."""
import os

from dotenv import load_dotenv

load_dotenv()

# mock | openai | anthropic
# mock은 API 키 없이 동작하는 시뮬레이션 모드 (개발·테스트용)
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "mock").lower()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-haiku-5-5")

DB_PATH = os.getenv("DB_PATH", "safe_counselor.db")
SESSION_TTL_MINUTES = int(os.getenv("SESSION_TTL_MINUTES", "60"))

# 방어 기본값. 시연 중에는 /api/defense 로 켜고 끌 수 있다.
DEFENSE_DEFAULT = os.getenv("DEFENSE_DEFAULT", "on").lower() == "on"
# 방어 ON/OFF 전환 권한 토큰 (시연자만 알고 있어야 함)
DEMO_TOKEN = os.getenv("DEMO_TOKEN", "change-me")

# 출력 가드에서 LLM 판정까지 쓸지 (끄면 규칙 기반만 사용, 응답이 빨라짐)
OUTPUT_LLM_JUDGE = os.getenv("OUTPUT_LLM_JUDGE", "on").lower() == "on"

# HTTPS로 배포할 때 true
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "false").lower() == "true"

# 시스템 프롬프트 유출 탐지용 카나리 토큰. 배포 시 임의의 값으로 바꿀 것.
CANARY_TOKEN = os.getenv("CANARY_TOKEN", "SC-CANARY-7f3a9")

# 세션당 분당 최대 요청 수
RATE_LIMIT_PER_MIN = int(os.getenv("RATE_LIMIT_PER_MIN", "20"))
