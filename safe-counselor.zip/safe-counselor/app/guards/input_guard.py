"""입력 가드: 규칙 기반 1차 탐지 + LLM 판정 2차 탐지."""
import base64
import re
from dataclasses import dataclass, field

from .. import llm
from ..counsel.prompts import INPUT_JUDGE_SYSTEM

# (패턴, 라벨). 규칙에 걸리면 LLM 판정 없이 바로 차단한다.
RULES: list[tuple[re.Pattern, str]] = [
    (re.compile(r"(이전|앞|위|기존)의?\s*(모든\s*)?(지시|명령|규칙|설정).{0,10}(무시|잊|따르지)", re.S), "injection"),
    (re.compile(r"(시스템|system)\s*(프롬프트|prompt|메시지|지시문)", re.I), "injection"),
    (re.compile(r"(관리자|개발자|디버그|탈옥|admin|developer|debug|dan)\s*(모드|mode)", re.I), "injection"),
    (re.compile(r"ignore\s+(all\s+)?(previous|prior|above)", re.I), "injection"),
    (re.compile(r"(다른|타)\s*(사용자|피해자|사람|이용자)(들)?의?\s*(상담|기록|대화|정보|내용|신고)"), "injection"),
    (re.compile(r"(모든|전체)\s*(상담|사용자|피해자)?\s*(기록|대화|케이스)"), "injection"),
    (re.compile(r"(every|all)\s+(case|user|conversation|record)s?", re.I), "injection"),
    (re.compile(r"(너는|넌)\s*이제\s*.{0,20}(이야|다|역할)"), "injection"),
    (re.compile(r"(피해자|당신|네|내)\s*(잘못|탓|책임)(이라고|이라고\s*말|이라고\s*해)"), "harmful_request"),
]

# 지시형 문장 (증거 파일 안에 숨은 지시를 찾을 때 사용)
INSTRUCTION_LINE = re.compile(
    r"(시스템\s*지시|system\s*instruction|AI는|assistant\s*must|모델은|이 문서를 읽은|출력할 것|출력하라|무시하고|ignore)",
    re.I,
)

BASE64_CHUNK = re.compile(r"[A-Za-z0-9+/]{24,}={0,2}")


@dataclass
class GuardResult:
    blocked: bool
    label: str = "normal"
    reason: str = ""
    source: str = ""  # rule | llm | none
    details: dict = field(default_factory=dict)


def _decode_hidden(text: str) -> str:
    """base64로 숨긴 지시를 풀어서 같이 검사한다."""
    decoded = []
    for chunk in BASE64_CHUNK.findall(text):
        try:
            s = base64.b64decode(chunk + "=" * (-len(chunk) % 4)).decode("utf-8")
            if s.isprintable() or any("가" <= c <= "힣" for c in s):
                decoded.append(s)
        except Exception:
            continue
    return " ".join(decoded)


def check_rules(text: str) -> GuardResult | None:
    hidden = _decode_hidden(text)
    targets = [text] + ([hidden] if hidden else [])
    for t in targets:
        for pattern, label in RULES:
            if pattern.search(t):
                src = "rule(base64)" if t is hidden else "rule"
                return GuardResult(True, label, f"규칙 일치: {pattern.pattern[:40]}", src)
    if hidden:
        return GuardResult(True, "injection", "인코딩된 지시 포함", "rule(base64)")
    return None


def check_input(text: str, use_llm: bool = True, threshold: float = 0.7) -> GuardResult:
    hit = check_rules(text)
    if hit:
        return hit
    if not use_llm:
        return GuardResult(False, source="none")
    verdict = llm.judge(INPUT_JUDGE_SYSTEM, text)
    if "error" in verdict:
        # 판정기 장애 시: 규칙을 통과했으니 상담은 계속하되 기록만 남긴다 (가용성 우선)
        return GuardResult(False, "unknown", verdict["error"], "llm_error")
    label = verdict.get("label", "normal")
    risk = float(verdict.get("risk", 0))
    blocked = label != "normal" and risk >= threshold
    return GuardResult(blocked, label, verdict.get("reason", ""), "llm", verdict)


def sanitize_evidence(text: str) -> tuple[str, int]:
    """증거 파일에서 지시형 문장을 제거한다. (정제된 텍스트, 제거한 줄 수)"""
    kept, removed = [], 0
    for line in text.splitlines():
        if INSTRUCTION_LINE.search(line) or check_rules(line):
            removed += 1
            kept.append("[보안상 제거된 문장]")
        else:
            kept.append(line)
    return "\n".join(kept), removed
