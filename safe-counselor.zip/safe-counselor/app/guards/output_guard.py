"""출력 가드: 카나리 토큰 → 개인정보 마스킹 → 2차 가해 표현 순서로 검사한다."""
import re
from dataclasses import dataclass, field

from .. import config, llm
from ..counsel.prompts import OUTPUT_JUDGE_SYSTEM

PII_PATTERNS = {
    "phone": re.compile(r"01[016789][-\s.]?\d{3,4}[-\s.]?\d{4}"),
    "rrn": re.compile(r"\d{6}[-\s]?[1-4]\d{6}"),
    "account": re.compile(r"\d{2,6}-\d{2,6}-\d{2,7}"),
    "email": re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"),
    "case_no": re.compile(r"\d{4}-[A-Z]{2,6}-\d{3,}"),
}

HARM_PHRASES = [
    "피해자 잘못", "당신 잘못이에요", "네 잘못", "자업자득", "조심했어야", "보낸 게 잘못",
    "피해자에게도 책임", "당신에게도 책임", "왜 그런 사진을",
]

SAFE_REPLY = (
    "이 부분은 답변드리기 어려워요. 대신 지금 겪고 계신 상황을 말씀해 주시면, "
    "할 수 있는 일을 하나씩 같이 정리해 드릴게요."
)


@dataclass
class OutputResult:
    text: str
    flags: list[str] = field(default_factory=list)
    replaced: bool = False


def _digits(s: str) -> str:
    return re.sub(r"\D", "", s)


def mask_pii(text: str, own_texts: list[str]) -> tuple[str, list[str]]:
    """사용자 본인이 이 세션에서 직접 말한 값이 아닌 개인정보 형식은 가린다."""
    own_joined = " ".join(own_texts)
    own_digits = _digits(own_joined)
    flags = []

    def repl(kind):
        def _r(m):
            value = m.group(0)
            if value in own_joined or (kind != "email" and _digits(value) and _digits(value) in own_digits):
                return value
            flags.append(f"pii:{kind}")
            return "[가려진 정보]"
        return _r

    for kind, pattern in PII_PATTERNS.items():
        text = pattern.sub(repl(kind), text)
    return text, flags


def check_output(text: str, own_texts: list[str]) -> OutputResult:
    # 1) 시스템 프롬프트 유출
    if config.CANARY_TOKEN in text or "[응답 원칙]" in text:
        return OutputResult(SAFE_REPLY, ["prompt_leak"], True)

    # 2) 2차 가해 표현 (규칙)
    if any(p in text for p in HARM_PHRASES):
        return OutputResult(SAFE_REPLY, ["secondary_harm"], True)

    # 3) 개인정보 마스킹
    text, flags = mask_pii(text, own_texts)

    # 4) LLM 판정 (선택)
    if config.OUTPUT_LLM_JUDGE:
        verdict = llm.judge(OUTPUT_JUDGE_SYSTEM, text)
        label = verdict.get("label", "safe")
        if label != "safe" and float(verdict.get("risk", 0)) >= 0.7:
            return OutputResult(SAFE_REPLY, flags + [label], True)

    return OutputResult(text, flags, False)
