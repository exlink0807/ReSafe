"""LLM 호출 래퍼. provider를 바꿔도 나머지 코드는 그대로 쓸 수 있게 한 곳에 모았다."""
import json
import re

from . import config


def _normalize(messages: list[dict]) -> list[dict]:
    """연속된 같은 role 메시지를 합치고, 첫 메시지가 user가 되도록 정리한다 (Anthropic 요구사항)."""
    out: list[dict] = []
    for m in messages:
        if out and out[-1]["role"] == m["role"]:
            out[-1] = {"role": m["role"], "content": out[-1]["content"] + "\n\n" + m["content"]}
        else:
            out.append({"role": m["role"], "content": m["content"]})
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out


def _openai(system: str, messages: list[dict], json_mode: bool) -> str:
    from openai import OpenAI

    client = OpenAI()
    kwargs = {"response_format": {"type": "json_object"}} if json_mode else {}
    resp = client.chat.completions.create(
        model=config.OPENAI_MODEL,
        messages=[{"role": "system", "content": system}] + messages,
        temperature=0.3,
        **kwargs,
    )
    return resp.choices[0].message.content or ""


def _anthropic(system: str, messages: list[dict], json_mode: bool) -> str:
    import anthropic

    client = anthropic.Anthropic()
    resp = client.messages.create(
        model=config.ANTHROPIC_MODEL,
        max_tokens=900,
        system=system,
        messages=messages,
        temperature=0.3,
    )
    return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")


def complete(system: str, messages: list[dict], json_mode: bool = False) -> str:
    messages = _normalize(messages)
    if config.LLM_PROVIDER == "openai":
        return _openai(system, messages, json_mode)
    if config.LLM_PROVIDER == "anthropic":
        return _anthropic(system, messages, json_mode)
    from . import mock_llm

    return mock_llm.complete(system, messages, json_mode)


def judge(system: str, text: str) -> dict:
    """판정용 호출. JSON 객체를 돌려받는다. 파싱에 실패하면 안전한 쪽(차단)으로 처리할 수 있게 error 키를 넣는다."""
    try:
        raw = complete(system, [{"role": "user", "content": text}], json_mode=True)
        match = re.search(r"\{.*\}", raw, re.S)
        return json.loads(match.group(0) if match else raw)
    except Exception as e:  # 네트워크 오류, 파싱 오류
        return {"error": str(e)}
