"""피해 유형 분류와 다음 단계 안내. LLM 없이 키워드로 동작해서 빠르고 예측 가능하다."""

VICTIM_TYPES = {
    "voice_phishing": {
        "name": "딥보이스 보이스피싱",
        "keywords": ["목소리", "전화", "송금", "보냈", "이체", "엄마", "아빠", "아들", "딸", "납치"],
        "steps": [
            "송금한 은행 고객센터나 112에 바로 지급정지를 요청하세요.",
            "통화 기록, 문자, 송금 내역을 캡처해 두세요.",
            "금융감독원(1332)에서 피해구제 절차를 상담받으세요.",
            "경찰청 사이버범죄 신고시스템(ECRM)에 신고하세요.",
        ],
    },
    "synthetic_media": {
        "name": "합성 영상·사진 유포 및 협박",
        "keywords": ["합성", "영상", "사진", "얼굴", "유포", "단톡", "협박", "몰카", "딥페이크"],
        "steps": [
            "영상이나 게시물을 지우지 말고 URL, 캡처, 게시자 계정을 먼저 저장하세요.",
            "협박에는 응하지 말고, 돈을 보내지 마세요.",
            "디지털성범죄피해자지원센터에 삭제 지원을 요청하세요.",
            "경찰에 신고하세요. 지원센터에서 신고 과정도 도와줄 수 있어요.",
        ],
    },
    "romance_scam": {
        "name": "로맨스 스캠",
        "keywords": ["연애", "애인", "만난 적", "해외", "군인", "사랑", "영상통화"],
        "steps": [
            "상대와의 연락을 멈추고 추가 송금을 하지 마세요.",
            "대화 내용과 상대 프로필, 송금 내역을 저장하세요.",
            "송금 은행에 지급정지를 요청하고 경찰에 신고하세요.",
        ],
    },
    "investment_scam": {
        "name": "유명인 사칭 투자사기",
        "keywords": ["투자", "코인", "주식", "리딩방", "수익", "유명인", "광고"],
        "steps": [
            "투자 앱이나 사이트에 추가 입금을 멈추세요.",
            "입금 내역, 리딩방 대화, 사이트 주소를 저장하세요.",
            "송금 은행 지급정지 요청 후 금융감독원(1332)과 경찰에 신고하세요.",
        ],
    },
}


def classify(texts: list[str]) -> dict | None:
    joined = " ".join(texts)
    best, best_score = None, 0
    for key, info in VICTIM_TYPES.items():
        score = sum(1 for k in info["keywords"] if k in joined)
        if score > best_score:
            best, best_score = key, score
    if not best:
        return None
    info = VICTIM_TYPES[best]
    return {"type": best, "name": info["name"], "steps": info["steps"]}
