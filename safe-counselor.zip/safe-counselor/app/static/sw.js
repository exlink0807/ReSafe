// PWA 설치 조건을 만족시키기 위한 최소 서비스 워커.
// 상담 내용이 기기에 남지 않도록 어떤 응답도 캐시하지 않는다.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", () => {});
