// Safe Counselor 화면 스크립트
// 상담 내용은 브라우저 저장소(localStorage 등)에 남기지 않는다. 화면 변수에만 둔다.

const SAFE_PAGE = "https://www.weather.go.kr/"; // 빠른 종료 시 이동할 평범한 페이지

const $ = (id) => document.getElementById(id);
const messagesEl = $("messages");

function addMessage(role, text, meta) {
  const el = document.createElement("div");
  el.className = `msg ${role}`;
  el.textContent = text; // innerHTML을 쓰지 않아 응답에 섞인 스크립트가 실행되지 않음
  if (meta) {
    const m = document.createElement("div");
    m.className = "meta";
    m.textContent = meta;
    el.appendChild(m);
  }
  messagesEl.appendChild(el);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function renderCase(c) {
  const box = $("caseBox");
  if (!c) return;
  box.classList.remove("muted");
  box.textContent = "";
  const title = document.createElement("strong");
  title.textContent = c.name;
  const ol = document.createElement("ol");
  c.steps.forEach((s) => {
    const li = document.createElement("li");
    li.textContent = s;
    ol.appendChild(li);
  });
  box.append(title, ol);
}

async function api(path, body) {
  const res = await fetch(path, {
    method: body === undefined ? "GET" : "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok && !data.reply) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

async function init() {
  await api("/api/session", {});
  const h = await api("/api/history").catch(() => ({ messages: [] }));
  if (h.messages.length === 0) {
    addMessage("assistant", "안녕하세요. 여기서 나눈 이야기는 다른 사람이 볼 수 없어요. 어떤 일이 있었는지 천천히 말씀해 주세요.");
  } else {
    h.messages.forEach((m) => addMessage(m.role, m.content));
  }
  if (new URLSearchParams(location.search).get("demo") === "1") {
    $("demoBar").classList.remove("hidden");
    refreshDefense();
  }
}

async function send(e) {
  e.preventDefault();
  const text = $("input").value.trim();
  if (!text) return;
  $("input").value = "";
  addMessage("user", text);
  $("sendBtn").disabled = true;
  try {
    const r = await api("/api/chat", { message: text });
    let meta = null;
    if (r.blocked) meta = `입력 가드 차단 (${r.guard.label}, ${r.guard.source})`;
    else if (r.guard) meta = `출력 가드 처리 (${r.guard.label})`;
    addMessage("assistant", r.reply, isDemo() ? meta : null);
    renderCase(r.case);
  } catch (err) {
    addMessage("assistant", "연결이 잠시 불안정해요. 다시 보내 주세요.");
  } finally {
    $("sendBtn").disabled = false;
  }
}

async function uploadEvidence(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  if (file.size > 20000) {
    addMessage("assistant", "파일이 너무 커요. 20KB 이하의 텍스트 파일만 올릴 수 있어요.");
    return;
  }
  const content = await file.text();
  const r = await api("/api/evidence", { filename: file.name, content });
  let msg = `'${file.name}' 자료를 받았어요. 이제 이 자료에 대해 물어보셔도 돼요.`;
  if (r.removed_lines && isDemo()) msg += ` (숨은 지시 ${r.removed_lines}줄 제거됨)`;
  addMessage("assistant", msg);
  ev.target.value = "";
}

// 빠른 종료: 서버 기록 삭제 → 화면 비우기 → 방문 기록을 교체해 뒤로 가기로 돌아올 수 없게
function quickExit() {
  try {
    navigator.sendBeacon("/api/session/delete");
  } catch (_) {}
  messagesEl.textContent = "";
  try { sessionStorage.clear(); } catch (_) {}
  history.replaceState(null, "", "/static/blank.html");
  location.replace(SAFE_PAGE);
}

function isDemo() {
  return !$("demoBar").classList.contains("hidden");
}

async function refreshDefense() {
  const r = await api("/api/defense");
  const badge = $("defenseState");
  badge.textContent = r.defense ? "방어 ON" : "방어 OFF";
  badge.className = `badge ${r.defense ? "on" : "off"}`;
}

async function setDefense(enabled) {
  const res = await fetch("/api/defense", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Demo-Token": $("demoToken").value },
    body: JSON.stringify({ enabled }),
  });
  if (!res.ok) alertInline("데모 토큰이 맞지 않아요.");
  refreshDefense();
}

function alertInline(text) {
  addMessage("assistant", text, "시연 안내");
}

$("chatForm").addEventListener("submit", send);
$("input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) send(e);
});
$("evidence").addEventListener("change", uploadEvidence);
$("exitBtn").addEventListener("click", quickExit);
document.addEventListener("keydown", (e) => { if (e.key === "Escape") quickExit(); });
$("defenseOn").addEventListener("click", () => setDefense(true));
$("defenseOff").addEventListener("click", () => setDefense(false));

if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
init();
