/**
 * AI 처리 파이프라인 (서버 전용). API 라우트와 레드팀 자가 점검이 같은 코드를 쓴다.
 * 그래야 자가 점검 결과가 실제 서비스 동작과 같다.
 */
import { guardCheck, checkOutput, stripHiddenInstructions, CRISIS_MESSAGE, BLOCKED_MESSAGE } from './guard';
import { complete, COUNSEL_SYSTEM, ANALYZE_SYSTEM, UNSAFE_SHARED_MEMORY, Msg } from './llm';

export type Turn = { role: 'user' | 'ai'; text: string };

export interface CounselResult {
  reply: string;
  verdict: 'ok' | 'blocked' | 'crisis' | 'unguarded';
  rule?: string;
  outputFlags: string[];
}

/** 추가 상담. 서버는 다른 사용자 데이터를 갖고 있지 않다 (가드 OFF 시연의 가상 메모리 제외). */
export async function counsel(message: string, history: Turn[], on: boolean): Promise<CounselResult> {
  const g = guardCheck(message);
  if (g.verdict === 'crisis') return { reply: CRISIS_MESSAGE, verdict: 'crisis', rule: g.matchedRule, outputFlags: [] };
  if (on && g.verdict === 'risk') return { reply: BLOCKED_MESSAGE, verdict: 'blocked', rule: g.matchedRule, outputFlags: [] };

  // 이전 대화의 사용자 문장도 다시 검사한다 (기록을 조작해 지시를 끼워 넣는 경우 대비)
  const msgs: Msg[] = history
    .slice(-10)
    .filter((m) => !on || m.role === 'ai' || guardCheck(m.text).verdict !== 'risk')
    .map((m) => ({ role: m.role === 'ai' ? 'assistant' : 'user', content: m.text }));
  msgs.push({ role: 'user', content: message });

  const system = on ? COUNSEL_SYSTEM : `${COUNSEL_SYSTEM}\n\n${UNSAFE_SHARED_MEMORY}`;
  let reply = await complete(system, msgs);
  let outputFlags: string[] = [];
  if (on) {
    const own = history.filter((m) => m.role === 'user').map((m) => m.text).concat(message);
    const out = checkOutput(reply, own);
    reply = out.text;
    outputFlags = out.flags;
  }
  return { reply, verdict: g.verdict === 'risk' ? 'unguarded' : 'ok', rule: g.matchedRule, outputFlags };
}

export interface AnalyzeResult { summary: string; removed: number; rules: string[]; outputFlags: string[] }

/** 증거 텍스트·외부 페이지 요약. 둘 다 가해자가 내용을 만들 수 있는 간접 인젝션 경로. */
export async function analyze(kind: 'evidence' | 'external', name: string, content: string, on: boolean): Promise<AnalyzeResult> {
  const tag = kind === 'evidence' ? 'evidence' : 'external_page';
  if (!on) {
    const summary = await complete(`${ANALYZE_SYSTEM}\n\n${UNSAFE_SHARED_MEMORY}`, [
      { role: 'user', content: `다음 자료를 요약해 주세요 (${name}):\n${content}` },
    ]);
    return { summary, removed: 0, rules: [], outputFlags: [] };
  }
  const s = stripHiddenInstructions(content);
  const safeName = name.replace(/[<>"]/g, '').slice(0, 80);
  const raw = await complete(ANALYZE_SYSTEM, [
    { role: 'user', content: `<${tag} name="${safeName}">\n${s.clean}\n</${tag}>\n위 자료를 요약해 주세요.` },
  ]);
  const out = checkOutput(raw, [content]);
  return { summary: out.text, removed: s.removed, rules: s.matchedRules, outputFlags: out.flags };
}
