/** AI API 라우트 공통: 속도 제한, 가드 ON/OFF 결정, 요청 검증. 서버 전용. */
import { NextRequest, NextResponse } from 'next/server';

const hits = new Map<string, number[]>();
const LIMIT = Number(process.env.AI_RATE_LIMIT_PER_MIN || 30);

/** IP 기준 분당 요청 제한 (서버리스에서는 인스턴스별 best-effort). */
export function rateLimited(req: NextRequest): NextResponse | null {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'local';
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60_000);
  if (arr.length >= LIMIT) return NextResponse.json({ error: '잠시 후 다시 시도해 주세요.' }, { status: 429 });
  arr.push(now);
  hits.set(ip, arr);
  return null;
}

/**
 * 가드는 기본 ON. 클라이언트가 OFF를 요청해도 서버의 DEMO_TOKEN과 일치하는 헤더가 있을 때만 끈다.
 * (이전 구조는 브라우저 상태만 바꾸면 누구나 가드를 끌 수 있었다.)
 */
export function guardOn(req: NextRequest, requestedOff: unknown): boolean {
  if (requestedOff !== false) return true;
  const token = process.env.DEMO_TOKEN;
  if (!token) return true; // 토큰이 설정되지 않은 배포에서는 끌 수 없다
  return req.headers.get('x-demo-token') !== token;
}

export function badRequest(msg = '요청 형식이 올바르지 않습니다.') {
  return NextResponse.json({ error: msg }, { status: 422 });
}
