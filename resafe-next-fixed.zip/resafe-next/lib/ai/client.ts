'use client';
/**
 * 브라우저 → AI API 호출. 가드 판정은 전부 서버가 한다.
 * 데모 토큰은 화면 메모리에만 두고 localStorage에 저장하지 않는다.
 */

let demoToken = '';
export function setDemoToken(t: string) { demoToken = t; }
export function hasDemoToken() { return demoToken.length > 0; }

async function post<T>(path: string, body: Record<string, unknown>, guard: boolean): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (!guard && demoToken) headers['X-Demo-Token'] = demoToken;
  const r = await fetch(path, { method: 'POST', headers, body: JSON.stringify({ ...body, guard }) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok && !d.reply && !d.summary) throw new Error(d.error || `HTTP ${r.status}`);
  return d as T;
}

export type ChatRes = { reply: string; verdict: 'ok' | 'blocked' | 'crisis' | 'unguarded' | 'error'; rule?: string; outputFlags?: string[]; guardOn: boolean };
export type GuardRes = { verdict: 'ok' | 'blocked' | 'crisis'; message?: string; rule?: string; guardOn: boolean };
export type AnalyzeRes = { summary: string; removed: number; rules: string[]; outputFlags?: string[]; guardOn: boolean };

export const aiChat = (message: string, history: { role: 'user' | 'ai'; text: string }[], guard: boolean) =>
  post<ChatRes>('/api/ai/chat', { message, history }, guard);
export const aiGuard = (text: string, guard: boolean) => post<GuardRes>('/api/ai/guard', { text }, guard);
export const aiAnalyze = (kind: 'evidence' | 'external', name: string, content: string, guard: boolean) =>
  post<AnalyzeRes>('/api/ai/analyze', { kind, name, content }, guard);
