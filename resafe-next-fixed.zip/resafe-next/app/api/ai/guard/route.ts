import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { guardCheck, CRISIS_MESSAGE, BLOCKED_MESSAGE } from '@/lib/ai/guard';
import { rateLimited, guardOn, badRequest } from '@/lib/ai/http';

/** Report 접수의 직접 입력 답변 검사. 선택지 버튼 답변은 검사하지 않는다. */
const Body = z.object({ text: z.string().min(1).max(2000), guard: z.boolean().optional() });

export async function POST(req: NextRequest) {
  const limited = rateLimited(req);
  if (limited) return limited;
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return badRequest();
  const on = guardOn(req, parsed.data.guard);
  const g = guardCheck(parsed.data.text);
  if (g.verdict === 'crisis') return NextResponse.json({ verdict: 'crisis', message: CRISIS_MESSAGE, rule: g.matchedRule, guardOn: on });
  if (on && g.verdict === 'risk') return NextResponse.json({ verdict: 'blocked', message: BLOCKED_MESSAGE, rule: g.matchedRule, guardOn: on });
  return NextResponse.json({ verdict: 'ok', guardOn: on });
}
