import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { analyze } from '@/lib/ai/pipeline';
import { rateLimited, guardOn, badRequest } from '@/lib/ai/http';

/**
 * 증거 텍스트(evidence) 또는 피해 후보 페이지(external) 요약.
 * 원문은 이 요청 처리 중에만 메모리에 있고 저장하지 않는다.
 */
const Body = z.object({
  kind: z.enum(['evidence', 'external']),
  name: z.string().max(200),
  content: z.string().min(1).max(20000),
  guard: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  const limited = rateLimited(req);
  if (limited) return limited;
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return badRequest();
  const on = guardOn(req, parsed.data.guard);
  try {
    const r = await analyze(parsed.data.kind, parsed.data.name, parsed.data.content, on);
    return NextResponse.json({ ...r, guardOn: on });
  } catch {
    return NextResponse.json({ summary: '지금 요약이 지연되고 있어요. 잠시 후 다시 시도해 주세요.', error: true }, { status: 503 });
  }
}
