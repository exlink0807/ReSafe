import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { counsel } from '@/lib/ai/pipeline';
import { PROVIDER } from '@/lib/ai/llm';
import { rateLimited, guardOn, badRequest } from '@/lib/ai/http';

/**
 * 추가 상담. 이 라우트는 DB를 쓰지 않는다 (대화는 피해자 브라우저에만 남음).
 * 서버가 다른 사용자 데이터를 아예 갖고 있지 않으므로, LLM이 무엇을 요청받아도 남의 정보를 꺼낼 수 없다 (구조적 격리).
 */
const Body = z.object({
  message: z.string().min(1).max(2000),
  history: z.array(z.object({ role: z.enum(['user', 'ai']), text: z.string().max(4000) })).max(20).default([]),
  guard: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  const limited = rateLimited(req);
  if (limited) return limited;
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return badRequest();
  const on = guardOn(req, parsed.data.guard);
  try {
    const r = await counsel(parsed.data.message, parsed.data.history, on);
    return NextResponse.json({ ...r, guardOn: on, provider: PROVIDER });
  } catch {
    return NextResponse.json({ reply: '지금 응답이 지연되고 있어요. 잠시 후 다시 보내 주세요.', verdict: 'error', guardOn: on }, { status: 503 });
  }
}
