import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { runRedteam } from '@/lib/ai/redteam';
import { PROVIDER } from '@/lib/ai/llm';
import { rateLimited, badRequest } from '@/lib/ai/http';

/**
 * 화이트햇 엔진 · AI 레드팀 자가 점검 (scope: self-test).
 * 규칙 점검은 누구나 실행 가능(비용 없음). 파이프라인 점검은 실제 LLM을 부르므로 데모 토큰이 필요하다.
 */
const Body = z.object({ pipeline: z.boolean().default(false) });

export async function POST(req: NextRequest) {
  const limited = rateLimited(req);
  if (limited) return limited;
  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return badRequest();
  const pipeline = parsed.data.pipeline;
  if (pipeline && PROVIDER !== 'mock') {
    const token = process.env.DEMO_TOKEN;
    if (!token || req.headers.get('x-demo-token') !== token) {
      return NextResponse.json({ error: '파이프라인 점검은 데모 토큰이 필요해요.' }, { status: 403 });
    }
  }
  try {
    const out = await runRedteam(pipeline);
    return NextResponse.json({ ...out, provider: PROVIDER, scope: 'self-test', at: new Date().toISOString() });
  } catch {
    return NextResponse.json({ error: '자가 점검 실행 중 오류가 났어요.' }, { status: 500 });
  }
}
