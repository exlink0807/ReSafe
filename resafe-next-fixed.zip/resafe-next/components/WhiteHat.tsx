'use client';

import { useState } from 'react';

type Row = {
  id: string; category: string; kind: string; expect: 'block' | 'allow' | 'crisis';
  v1: string; v2: string; rule?: string; v1Pass: boolean; v2Pass: boolean; leakOff?: boolean; leakOn?: boolean;
};
type Summary = {
  attacks: number; benign: number; crisis: number;
  detectV1: number; detectV2: number; falsePosV1: number; falsePosV2: number; crisisV1: number; crisisV2: number;
  leakOff?: number; leakOn?: number;
};

const LABEL: Record<string, string> = { block: '차단', allow: '통과', crisis: '위기 안내' };

/**
 * 화이트햇 엔진 · AI 레드팀 자가 점검.
 * 대상은 우리 서비스의 AI 보안 레이어뿐이다 (scope: self-test). 외부 시스템은 건드리지 않는다.
 */
export default function WhiteHat() {
  const [data, setData] = useState<{ results: Row[]; summary: Summary; provider: string; at: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [pipeline, setPipeline] = useState(true);
  const [err, setErr] = useState('');

  async function run() {
    setBusy(true);
    setErr('');
    try {
      const r = await fetch('/api/redteam', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pipeline }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || '실패');
      setData(d);
    } catch (e) {
      setErr(e instanceof Error ? e.message : '실패');
    } finally {
      setBusy(false);
    }
  }

  const s = data?.summary;
  return (
    <div className="card p-5">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold">🛡️ 화이트햇 엔진 · AI 레드팀 자가 점검</h3>
        <span className="rounded bg-[var(--panel-2)] px-2 py-0.5 text-[10px] text-[var(--muted)]">scope: self-test</span>
      </div>
      <p className="mb-3 text-xs text-[var(--muted)]">
        우리 서비스의 AI에 공격 문장 {s?.attacks ?? 15}종, 정상 상담 {s?.benign ?? 17}종, 위기 표현 {s?.crisis ?? 3}종을 직접 넣어
        방어가 제대로 동작하는지 점검합니다. 외부 사이트나 다른 시스템은 대상으로 삼지 않습니다.
      </p>
      <div className="mb-3 flex flex-wrap items-center gap-3 text-xs">
        <button onClick={run} disabled={busy} className="btn-primary rounded-lg px-4 py-2 text-sm font-semibold text-white">
          {busy ? '점검 중…' : '자가 점검 실행'}
        </button>
        <label className="flex items-center gap-1 text-[var(--muted)]">
          <input type="checkbox" checked={pipeline} onChange={(e) => setPipeline(e.target.checked)} />
          AI 파이프라인까지 점검 (가드 OFF/ON 정보 유출 비교)
        </label>
      </div>
      {err && <p className="mb-2 text-xs" style={{ color: '#f87171' }}>{err}</p>}

      {s && data && (
        <>
          <div className="mb-3 grid grid-cols-2 gap-2 text-center text-xs sm:grid-cols-4">
            <Metric label="공격 탐지" before={`${s.detectV1}/${s.attacks}`} after={`${s.detectV2}/${s.attacks}`} />
            <Metric label="정상 상담 오탐" before={`${s.falsePosV1}/${s.benign}`} after={`${s.falsePosV2}/${s.benign}`} />
            <Metric label="위기 신호 감지" before={`${s.crisisV1}/${s.crisis}`} after={`${s.crisisV2}/${s.crisis}`} />
            {s.leakOff !== undefined && (
              <Metric label="정보 유출 (가드 OFF → ON)" before={`${s.leakOff}/${s.attacks}`} after={`${s.leakOn}/${s.attacks}`} />
            )}
          </div>
          <p className="mb-2 text-[11px] text-[var(--muted)]">
            왼쪽 숫자: 자가 점검 전 규칙(v1) · 오른쪽 숫자: 현재 규칙(v2) · 모델: {data.provider}
            {data.provider === 'mock' ? ' (시뮬레이션 — 발표용 수치는 실제 LLM으로 다시 측정)' : ''} · {new Date(data.at).toLocaleString()}
          </p>
          <div className="max-h-80 overflow-auto">
            <table className="w-full text-xs">
              <thead className="text-left text-[var(--muted)]">
                <tr><th className="py-1">ID</th><th>유형</th><th>기대</th><th>v1</th><th>v2</th>{s.leakOff !== undefined && <th>유출 OFF→ON</th>}</tr>
              </thead>
              <tbody>
                {data.results.map((r) => (
                  <tr key={r.id} className="border-t border-[#262f45]">
                    <td className="py-1">{r.id}</td>
                    <td>{r.category}</td>
                    <td>{LABEL[r.expect]}</td>
                    <td style={{ color: r.v1Pass ? 'var(--muted)' : '#f87171' }}>{LABEL[r.v1]}</td>
                    <td style={{ color: r.v2Pass ? 'var(--accent-2)' : '#f87171' }} title={r.rule}>{LABEL[r.v2]}</td>
                    {s.leakOff !== undefined && (
                      <td>{r.leakOff === undefined ? '-' : `${r.leakOff ? '유출' : '안전'} → ${r.leakOn ? '유출' : '안전'}`}</td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function Metric({ label, before, after }: { label: string; before: string; after: string }) {
  return (
    <div className="rounded-lg bg-[var(--panel-2)] p-2">
      <div className="text-[var(--muted)]">{label}</div>
      <div className="mt-1 text-sm"><span className="text-[var(--muted)]">{before}</span> → <b style={{ color: 'var(--accent-2)' }}>{after}</b></div>
    </div>
  );
}
